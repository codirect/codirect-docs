## coDIRECT Companion Module Help

If you are stuck, please check out the official [documentation](https://docs.codirect.live)

If you are experiencing an issue with the module, please report it to the official [issues form](https://docs.google.com/forms/d/e/1FAIpQLSdmP2jmH5gLkLiWSvvt5ZJBX1EiRQ_314E3VrvgPxUkqLvyWw/viewform)
